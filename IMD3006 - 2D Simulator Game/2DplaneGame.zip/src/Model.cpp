#include "Model.h"
void Model::setup()
{
	aircraft.setup();
	runway.setup();
	radar.setup();
}